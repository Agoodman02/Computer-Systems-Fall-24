Read.Me

Amber Goodman
9/17/24


Started with getting execvp to work
moved on to backgrounding processes
worked on file redirect and I/O
added in pipes
